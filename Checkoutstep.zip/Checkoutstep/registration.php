<?php
 /**
 * Hide price for the guest users
 * 
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Anokesh_Checkoutstep',
    __DIR__
);
