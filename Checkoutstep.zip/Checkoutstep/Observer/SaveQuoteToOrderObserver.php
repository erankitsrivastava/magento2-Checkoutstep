<?php

namespace Anokesh\Checkoutstep\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

/**
 * Class SaveDeliveryDateToOrderObserver
 * @package Anokesh\Checkoutstep\Observer\Observer
 */
class SaveQuoteToOrderObserver implements ObserverInterface
{
    /**
     * @param EventObserver $observer
     * @return $this
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     */
    public function execute(EventObserver $observer)
    {
        $order = $observer->getOrder();
        $quote = $observer->getQuote();
        if($order && $quote->getData('profile_management_data')){
            try{
                $order->setData('profile_management_data', $quote->getData('profile_management_data'));
                $order->save();
            } catch (\Exception $exception) {
                throw new \Magento\Framework\Exception\CouldNotSaveException(
                    __('Unable to update the Profile Management Data to Order'),
                    $exception
                );
            }
        }
        return $this;
    }

}