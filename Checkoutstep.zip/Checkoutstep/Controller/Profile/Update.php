<?php

namespace Anokesh\Checkoutstep\Controller\Profile;

use Magento\Framework\App\Action\Context;

/**
 * Class Update
 * @package Anokesh\Checkoutstep\Controller\Profile
 */
class Update extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\Checkout\Model\Session $checkoutSession
     */
    private $_checkoutSession;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    private $jsonResultFactory;

    /**
     * Update constructor.
     * @param Context $context
     * @param \Magento\Checkout\Model\SessionFactory $checkoutSession
     */
    public function __construct(
        Context $context,
        \Magento\Checkout\Model\SessionFactory $checkoutSession,
        \Magento\Framework\Controller\Result\JsonFactory $jsonResultFactory
    ){
         $this->_checkoutSession = $checkoutSession;
        $this->jsonResultFactory = $jsonResultFactory;
         parent::__construct($context);
    }

    public function execute()
    {
        try{
            $result = $this->jsonResultFactory->create();
            $return = false;
            $request = $this->getRequest();
            if ($request->getParam('first_name') &&
                $request->getParam('last_name') &&
                $request->getParam('email') &&
                $request->getParam('date_field') &&
                $request->getParam('fav_color') &&
                $request->getParam('comment')
            ){
                $checkoutSession = $this->_checkoutSession->create();
                $quote = $checkoutSession->getQuote();
                $quote->setProfileManagementData(@json_encode($request->getParams()));
                $quote->save();
                $return = true;
            }
        }catch (\Exception $e){
            $return = false;
        }
        $result->setData($return);
        return $result;
    }
}