define(
    ['jquery', 'ko', 'Magento_Ui/js/form/form', 'underscore', 'Magento_Checkout/js/model/step-navigator', 'mage/url'],

    function(jQuery,
             ko,
             Component,
             _,
             stepNavigator,
             urlmodal) {
        'use strict';
        return Component.extend({
            defaults: {
                template: 'Anokesh_Checkoutstep/extra-step'
            },
            isVisible: ko.observable(true),
            source: ko.observable({}),
            setAdditionalData: function(data) {
                _.each(data, function(value, name) {
                    this.source.set('data.' + name, value);
                }, this);

                return this;
            },
            /**
             *
             * @returns {*}
             */
            initialize: function() {
                this._super();
                stepNavigator.registerStep('extra_step',
                    null, 'Profile Management',
                    this.isVisible,
                    _.bind(this.navigate, this),
                    15);

                return this;
            },
            navigate: function() {
                this.isVisible(true);
            },

            /**
             * @returns void
             */
            navigateToNextStep: function() {
                if (true) {
                    var controller_url = urlmodal.build('checkoutstep/profile/update');
                    var formData = jQuery('#profile-management-form').serializeArray().reduce(function(obj, item) {
                        obj[item.name] = item.value;
                        return obj;
                    }, {});
                    jQuery.post(
                        controller_url,
                        formData).done(function(msg) {
                        console.log(msg);
                        stepNavigator.next();
                    }).fail(function(thrownError) {
                        console.log('error');
                        console.log(xhr);
                        console.log(thrownError);
                    });
                }
            }
        });
    });